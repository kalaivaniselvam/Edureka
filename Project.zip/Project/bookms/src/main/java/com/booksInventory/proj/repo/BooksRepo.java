package com.booksInventory.proj.repo;

import com.booksInventory.proj.domain.BooksDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BooksRepo extends JpaRepository<BooksDetails, Integer> {
}

package com.booksInventory.proj;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@RestController
public class ClientOfBookms {
    @Autowired
    private WebClient webClient;


    @GetMapping("/client-book")
    @CircuitBreaker(name = "bookmsclient", fallbackMethod = "bookmsfallback")
    public Mono<Object> getIssueBookFromIssuems() {
        return webClient.get().uri("/bookms").retrieve().bodyToMono(Object.class);
    }

    private Mono bookmsfallback(CallNotPermittedException ex) {
        System.out.println("Fallback is invoked");
        return Mono.just(new String[]{"x", "y", "z"});
    }

}

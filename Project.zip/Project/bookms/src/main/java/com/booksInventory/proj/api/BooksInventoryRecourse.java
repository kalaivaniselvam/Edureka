package com.booksInventory.proj.api;

import com.booksInventory.proj.domain.BooksDetails;
import com.booksInventory.proj.repo.BooksRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("booksInventory")
public class BooksInventoryRecourse {
    private static final Logger LOGGER = LoggerFactory.getLogger(BooksInventoryRecourse.class);

    @Autowired
    private BooksRepo booksRepo;

    //@GetMapping("/Books")
    @GetMapping
     public Optional<BooksDetails> getAllBooksDetails() {
        LOGGER.info("Getting all books from database");
       Optional<BooksDetails> bookFound = booksRepo.findById(1);
      Integer totalCopies = bookFound.get().getTotalCopies();
      Integer issuedCopies = bookFound.get().getIssuedCopies();
      Integer availCopies = totalCopies - issuedCopies;

        return bookFound;
    }


    @PostMapping ("/addBook")
    public ResponseEntity<BooksDetails> addBook(@RequestBody BooksDetails booksDetails) {
        LOGGER.info("Adding new book");
        BooksDetails savedBook = booksRepo.save(booksDetails);
        LOGGER.info("Added new book");
        return ResponseEntity.created(URI.create((booksDetails.getTitle()))).body(savedBook);
    }

    @GetMapping("/AllBooks")
    public ResponseEntity<Object> getAllBooks() {
        LOGGER.info("Getting all books");
        List<BooksDetails> bookDetails = booksRepo.findAll();
        if (bookDetails.isEmpty()) {
            LOGGER.error("No book found");
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(bookDetails);
    }

    @GetMapping("/individualBook/{id}")
    public ResponseEntity<Object> getSingleBookById(@PathVariable Integer id) {
        LOGGER.info("Getting single data");
        Optional<BooksDetails> bookFound = booksRepo.findById(id);

        if (bookFound.isEmpty()) {
            LOGGER.error("Wrong id");
            return ResponseEntity.notFound().build();

        }

        return ResponseEntity.ok(bookFound.get());
    }

    @PutMapping("/updateBook/{id}")
    public ResponseEntity<Object> updateBook(@PathVariable Integer id, @RequestBody Integer issuedCopies) {
        LOGGER.info("Updating books details");
        Optional<BooksDetails> bookFound = booksRepo.findById(id);
        BooksDetails bookUpdate = new BooksDetails();

        if (bookFound.isEmpty()) {
            LOGGER.error("book details are empty");
            return ResponseEntity.notFound().build();

        } else if (bookFound.isPresent() && id.equals(bookFound.get().getId())) {
            bookFound.get().setIssuedCopies(issuedCopies);
            bookUpdate.setIssuedCopies(issuedCopies);
            bookUpdate.setId(id);
            bookUpdate.setTotalCopies(bookFound.get().getTotalCopies());
            bookUpdate.setAuthor(bookFound.get().getAuthor());
            bookUpdate.setIsbn(bookFound.get().getIsbn());
            bookUpdate.setPrice(bookFound.get().getPrice());
            bookUpdate = booksRepo.save(bookUpdate);
            LOGGER.error("Updated the books details");
        } else {
            LOGGER.error("book id is mismatched");
            return ResponseEntity.notFound().build();
        }
        //return ResponseEntity.created(URI.create((bookDetails.getAuthor()))).body(bookUpdate);
            return ResponseEntity.ok(bookUpdate);
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity<Object> deleteBook(@PathVariable Integer id) {
        LOGGER.info("Deleting book data");
        Optional<BooksDetails> bookFound = booksRepo.findById(id);
        if (bookFound.isEmpty()) {
            LOGGER.error("book data is empty");
            return ResponseEntity.notFound().build();
        } else if (bookFound.isPresent()) {
            booksRepo.deleteById(id);
            LOGGER.error("Deleted the book details");
        }
        return  ResponseEntity.ok().body("Deleted");
    }

}

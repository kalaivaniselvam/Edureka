package com.issueBook.proj;

import com.issueBook.proj.domain.BookDetails;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@RestController
public class ClientOfIssuems {
    @Autowired
    private WebClient webClient;
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientOfIssuems.class);

    @GetMapping("/issue-book")
    @CircuitBreaker(name = "issuemsclient", fallbackMethod = "issuemsfallback")
    public Mono<BookDetails> getBookFromBookms() {
       BookDetails bk= webClient.get().uri("/booksInventory").retrieve().bodyToMono(BookDetails.class).block();
      Integer issuedCopies=  bk.getIssuedCopies();
      LOGGER.info("issuedCopies-->"+issuedCopies);
        return webClient.get().uri("/booksInventory").retrieve().bodyToMono(BookDetails.class);
    }

    private Mono issuemsfallback(CallNotPermittedException ex) {
        System.out.println("Fallback is invoked");
        return Mono.just(new String[]{"x", "y", "z"});
    }

}

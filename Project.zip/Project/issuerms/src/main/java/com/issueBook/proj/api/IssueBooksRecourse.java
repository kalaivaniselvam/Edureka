package com.issueBook.proj.api;

import com.issueBook.proj.domain.BookDetails;
import com.issueBook.proj.domain.IssueBooksDetails;
import com.issueBook.proj.repo.IssueBooksRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
//import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("issueBooks")
public class IssueBooksRecourse {
    private static final Logger LOGGER = LoggerFactory.getLogger(IssueBooksRecourse.class);

    @Autowired
    private WebClient webClient;
    @Autowired
    private IssueBooksRepo booksRepo;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping ("/bookDetailsFromBookms")
    public ResponseEntity<String> getBookDetailsFromBookms(Integer id, IssueBooksDetails issueBooks) {
        LOGGER.info("Inside book details");
       BookDetails bookDtls;

       boolean isBooksAvailable = false;
     bookDtls = webClient.get().uri("/booksInventory/individualBook/{id}",id).retrieve().
                bodyToMono(BookDetails.class).block();
        LOGGER.info ("book details-->>>"+bookDtls);
        LOGGER.info ("issued copies-->>>"+bookDtls.getIssuedCopies());
        LOGGER.info ("total copies-->>>"+bookDtls.getTotalCopies());
        LOGGER.info ("avail copies-->>>"+issueBooks.getNoOfCopies());
        if (null == bookDtls ||( bookDtls.getTotalCopies()- bookDtls.getIssuedCopies() < issueBooks.getNoOfCopies()) ){
            throw new RuntimeException("Not enough copies");
        }
        bookDtls.setIssuedCopies(bookDtls.getIssuedCopies()+issueBooks.getNoOfCopies());
        LOGGER.info ("after issued remaining copies-->>>"+bookDtls.getIssuedCopies());
        webClient.put().uri("/booksInventory/updateBook/{id}",id).contentType(MediaType.APPLICATION_JSON)
                .bodyValue(bookDtls.getIssuedCopies())
                .retrieve().
                bodyToMono(BookDetails.class).block();;
        booksRepo.save(issueBooks);
        return  ResponseEntity.ok().body("Updated");
        //return bookDtls;
    }
   private void issueBookToCustomer(BookDetails bookDetails) {

   }
    @GetMapping ("/bookDetails/{custId}")
    public ResponseEntity<Optional<IssueBooksDetails>> viewCustomerOrder(@PathVariable Integer custId) {
       // getBookDetailsFromBookms();
        Optional<IssueBooksDetails> viewOrder = booksRepo.findById(custId);
        LOGGER.info("the customer order details->>");
        return ResponseEntity.ok(viewOrder);
    }

    @GetMapping ("/bookDetailsForAll")
    public ResponseEntity<List<IssueBooksDetails>> viewAllCustomerOrder() {
        // getBookDetailsFromBookms();
        List<IssueBooksDetails> viewOrder = booksRepo.findAll();
        LOGGER.info("the customer order details->");
        return ResponseEntity.ok(viewOrder);
    }




}

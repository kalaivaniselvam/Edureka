package com.issueBook.proj.repo;

import com.issueBook.proj.domain.IssueBooksDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IssueBooksRepo extends JpaRepository<IssueBooksDetails, Integer> {
}
